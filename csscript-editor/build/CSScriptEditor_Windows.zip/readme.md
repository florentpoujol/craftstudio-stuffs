# CSScript Editor

This application allows you to edit `.cscript` files (including public properties) outside [CraftStudio](http://craftstud.io).

This is usefull for web player debugging for instance.  
Note that you can't read scripts inside projects that are open in a CraftStudio server (you need to stop the server).  
The projects and scripts data are saved in an `EditorData.txt` file in the application's root folder.


## Download

- [Download](http://florentpoujol.fr/content/craftstudio/csscripteditor) for Windows
- [Check the source on GitHub](https://github.com/florentpoujol/csscripteditor)

As it is made with [Unity3D](http://unity3d.com), you can use it from within the Unity editor, or you can built standalone executable for Windows, Mac or Linux.


## Public properties

The scripts's public properties (if any) are found at the top of the script and follow this pattern :

    --[[PublicProperties
    name type defaultValue
    /PublicProperties]]

- The name, type and defaultValue must be separated by at least one space and must exist on the same line.
- The type may be `boolean`, `number` or `string`.
- When the property is of type `string`, its value must be enclosed in double quotation marks (`"`).
- You may delete, move or modify any existing properties or add new properties.

Ie :

    --[[PublicProperties
    isAlive boolean true
    health  number  52.8
    name string "John"
    /PublicProperties]]


## Credits

[http://florentpoujol.fr](http://florentpoujol.fr)

Released under the MIT licence :

Copyright © 2013-2014 Florent POUJOL

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
